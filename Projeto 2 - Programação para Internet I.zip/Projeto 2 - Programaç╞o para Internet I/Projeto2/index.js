const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const pg = require('pg');

const app = express();
app.use(cors());
app.use(bodyParser.json());

const cliente = new pg.Client(
    {
        user: 'postgres',
        host: 'localhost',
        database: 'cliente',
        password: 'admin',
        port: 5432,
    }
);
cliente.connect();

app.get('/tbCliente', function(req, res){
    cliente.query('SELECT * FROM tbCliente')
    .then(
        function(ret){
            let array = [];
            for(cli of ret.rows){
                array.push(
                    {
                        codigoCliente: cli.codigo_cli,
                        nomeCliente: cli.nome_cli,
                        cpfCliente: cli.cpf_cli
                    }
                )
            }
            res.json(
                {
                    status: 'OK',
                    numeroDeResultados: array.lenght,
                    resultados: array
                }
            )
        }
    )
});

app.post('/insert', (req, res) => {
    let  codigo_cli = req.body.codigoCliente;
    let  nome_cli =  req.body.nomeCliente;
    let  CPF_cli = req.body.cpfCliente;
    cliente.query(
        {
            text: "INSERT INTO tbCliente (codigo_cli, nome_cli, CPF_cli) VALUES ($1, $2, $3)",
            values: [codigo_cli, nome_cli, CPF_cli]
        }
    );
});

app.post('/update', (req, res) => {
    let  codigo_cli = req.body.codigoCliente;
    let  nome_cli =  req.body.nomeCliente;
    let  CPF_cli = req.body.cpfCliente;
    cliente.query(
        "UPDATE tbCliente set nome_cli=?, CPF_cli=? where codigo_cli=?",[nome_cli, CPF_cli, codigo_cli]
    );
});

app.get('/tbCliente/:id', function(req, res) {
    cliente.query(
        {
            text: 'SELECT * FROM tbCliente WHERE id = $1',
            values: [req.params.id]
        }
        )
        .then(
            function (ret) {
                console.log(req.params.id, ret.rows);
                let tbCliente = ret.rows[0];
                res.json(
                    {
                        status: 'OK',
                        codigoCli: tbCliente.codigo_cli,
                        nomeCli: tbCliente.nome_cli,
                        cpfCli: tbCliente.cpf_cli
                    }
                    );
                }
                );
            });

app.get('/delete',function(req,res){
    let codigo_cli = req.query.codigo_cli;
    cliente.query("delete from tbCliente where = codigo_cli?",[codigo_cli],function(err,rows,fields){       
    if(!!err){
    console.log('Error' ,+ err);
}
else {console.log("deletedo");
res.json({status: 'deletado'});
}
});
})

app.listen(
    3000,
    function(){
        console.log('Servidor web funcionando');
    }
)
