CREATE TABLE tbCliente(
	codigo_cli INT PRIMARY KEY,
	nome_cli VARCHAR (100),
	CPF_cli CHAR (11)
);

INSERT INTO tbCliente(codigo_cli, nome_cli, CPF_cli)
VALUES (01, 'Amanda', '12345678998');

SELECT * FROM tbCliente;